
from django.conf.urls import url, include
from django.contrib.auth import views as auth_views

from login import views as login_views

urlpatterns = [
    url(r'^$', login_views.home, name='home'),
    url(r'^login/$', auth_views.login, {'template_name': 'login.html'}, name='login'),
    url(r'^logout/$', auth_views.logout, {'next_page': 'login'}, name='logout'),
    url(r'^signup/$', login_views.signup, name='signup'),
    url(r'^details/$', login_views.details, name='details'),
    ]
